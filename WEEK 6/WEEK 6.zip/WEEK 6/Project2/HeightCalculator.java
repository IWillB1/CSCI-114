import java.awt.*;

/**
 * <h2>HeightCalculator.java - Calculate the predicted height based on the input </h2>
 *
 * <h3>Instance variables:</h3>
 * <ul>
 *     <li> <code>gender</code> (<b>char</b>) - 'M' for male or 'F' for female
 *     <li> <code>momHeightFeet</code> (<b>int</b>) -Feet of mom's height
 *     <li> <code>momHeightInches</code> (<b>int</b>) -Inches of mom's height
 *     <li> <code>dadHeightFeet</code> (<b>int</b>) -Feet of dad's height
 *     <li> <code>dadHeightFeet</code> (<b>int</b>) -Inches of dad's height
 *     <li> <code>childHeightFeet</code> (<b>int</b>) -Feet of child's height
 *     <li> <code>childHeightInches</code> (<b>int</b>) -Inches of child's height
 * </ul>
 *
 * @author Will Bouasisavath
 * @version Module 6 Homework Project 2
 *
 */
public class HeightCalculator
{

    //Instance variables
    char gender;
    int momHeightFeet, momHeightInches, dadHeightFeet, dadHeightInches;
    int childHeightFeet = 0, childHeightInches = 0;

    public HeightCalculator(char gender, int momHeightFeet, int momHeightInches, int dadHeightFeet, int dadHeightInches) 
    {

        this.gender = Character.toUpperCase(gender);
        this.momHeightFeet = momHeightFeet;
        this.momHeightInches = momHeightInches;
        this.dadHeightFeet = dadHeightFeet;
        this.dadHeightInches = dadHeightInches;

    }

    // Getter for gender variable
    public char getGender() {
        return gender;
    }

    // Setter for gender variable
    public void setGender(char gender) {
        this.gender = gender;
    }

    // Getter for momHeightFeet
    public int getMomHeightFeet() {
        return momHeightFeet;
    }

    // Setter for momHeightFeet
    public void setMomHeightFeet(int momHeightFeet) {
        this.momHeightFeet = momHeightFeet;
    }

    // Getter for momHeightInches
    public int getMomHeightInches() {
        return momHeightInches;
    }

    // Setter for momHeightInches
    public void setMomHeightInches(int momHeightInches) {
        this.momHeightInches = momHeightInches;
    }

    // Getter for dadHeightFeet
    public int getDadHeightFeet() {
        return dadHeightFeet;
    }

    // Setter for dadHeightFeet
    public void setDadHeightFeet(int dadHeightFeet) {
        this.dadHeightFeet = dadHeightFeet;
    }

    // Getter for dadHeightInches
    public int getDadHeightInches() {
        return dadHeightInches;
    }

    // Setter for dadHeightInches
    public void setDadHeightInches(int dadHeightInches) {
        this.dadHeightInches = dadHeightInches;
    }

    //Getter for childHeightFeet
    public int getChildHeightFeet() {

        int childInches = 0;

        int dadInches = ((dadHeightFeet * 12) + dadHeightInches);
        int momInches = ((momHeightFeet * 12) + momHeightInches);

        if (gender == 'M') 
        {

             childInches = ((momInches * 13 / 12) + dadInches) / 2;

        }
        else if (gender == 'F') 
        {

            childInches = ((dadInches * 12 / 13) + momInches) / 2;

        }

        while ((childInches - 12) > -1) 
        {
            
            childHeightFeet++;
            childInches -= 12;
            
        }
        
        childHeightInches = childInches;
        //System.out.print( childHeightFeet + " " + childHeightInches);

        return childHeightFeet;
    }

    // Getter for childHeightFeet
    public int getChildHeightInches() {
        return childHeightInches;
    }

    // Setter for childHeightFeet
    public void setChildHeightFeet(int childHeightFeet) {
        this.childHeightFeet = childHeightFeet;
    }

    // Setter for childHeightInches
    public void setChildHeightInches(int childHeightInches) {
        this.childHeightInches = childHeightInches;
    }
}