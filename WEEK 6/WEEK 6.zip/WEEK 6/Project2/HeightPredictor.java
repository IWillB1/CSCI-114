import java.util.Scanner;

/**
 * <h2>HeightPredictor.java - Respond to a question, exclamation, or sentence</h2>
 *
 * <h3>Problem Statement:</h3>
 * <p> Write a program that takes a one-line sentence as input from the keyboard and prints a response based on what the sentence ends with.</p>
 *
 * <h3>Algorithm:</h3>
 * <p>In main:</p>
 * <ol>
 *     <li>Create Scanner
 *     <li>Prompt user 5 times for child's gender, mom height (feet), mom height (inches), dad height (inches)
 *     <li>Create variables and store the answers in appropriate spots
 *     <li>Create object from HeightCalculator named <code>child</code>, set newly created variables as the parameters
 *     <li>Print a statement telling the user the values of and getting <code>childHeightFeet</code> and <code>childHeightInches</code>
 * </ol>
 *
 * @author Will Bouasisavath
 * @version Module 6 Homework Project 2
 *
 */
public class HeightPredictor 
{

    public static void main(String[] args) 
    {

        String gender;
        int momHeightFeet, momHeightInches, dadHeightFeet, dadHeightInches;

        Scanner in = new Scanner(System.in);

        System.out.print("Please enter your child's gender (M for male, F for female):");
        gender = in.nextLine().toUpperCase();

        System.out.print("Please enter the mother's height (just feet first):");
        momHeightFeet = in.nextInt();

        System.out.print("Please enter the mother's height (just inches now):");
        momHeightInches = in.nextInt();

        System.out.print("Please enter the father's height (just feet first):");
        dadHeightFeet = in.nextInt();

        System.out.print("Please enter the father's height (just inches now):");
        dadHeightInches = in.nextInt();

        HeightCalculator person = new HeightCalculator(gender.charAt(0), momHeightFeet, momHeightInches, dadHeightFeet, dadHeightInches);
        System.out.print("\nThe predicted height for child is " + person.getChildHeightFeet() + " feet and " + person.getChildHeightInches() + " inches.");

    }

}