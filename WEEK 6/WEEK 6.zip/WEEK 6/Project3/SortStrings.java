import java.util.Scanner;

/**
 * <h2>SortStrings.java - Sorts and displays strings in lexicographic order/h2>
 *
 * <h3>Problem Statement:</h3>
 * <p>Write a program which prompts the user for three Strings, then sorts and displays them in lexicographic order on your screen:
 * <ul>
 *     <li>If the user enters "quit" at any prompt, then your program should end
 *     <li>Strip off any leading blanks in the Strings before sorting
 * </ul>
 * </p>
 *
 * <h3>Algorithm:</h3>
 * <p>In main:</p>
 * <ol>
 *     <li>Create Scanner object, along with a constant named SORTING equal to "quit"
 *     <li>Prompt user three strings
 *     <li>If <code>SORTING</code> was not entered (terminate if so), store the answers in an <b>Array</b> called <code>string</code>
 *     <li>Use two for loops and a if loop nested in the innermost loop, use compareTo going one by one through the array, saving in numerical (actually lexicographic) order
 *     <li>Loop through displaying the strings in the order they are in the string, which should be lexicographic order
 * </ol>
 *
 * @author Will Bouasisavath
 * @version Module 6 Homework Project 3
 *
 */
public class SortStrings 
{

    public static final String SORTING = "quit";

    public static void main(String[] args) 
    {
        String[] strings = {"", "", ""};

        Scanner in = new Scanner(System.in);

        int num = 1;
        String input;

        System.out.print("Please enter a string (or quit to terminate program):");
        input = in.nextLine();
        strings[num-1] = input.stripLeading();

        while (!(input.equals(SORTING)) && num < 3) 
        {

            System.out.print("Please enter a string (or quit to terminate program):");
            input = in.nextLine();
            strings[num] = input.stripLeading();

            num++;
        }

        if (num == 3 && !(input.equals(SORTING))) 
        {
            for(int i = 0; i < 2; ++i) 
            {
                for (int j = i + 1; j < 3; ++j) 
                {
                    if (strings[i].compareTo(strings[j]) > 0) 
                    {

                        String rep = strings[i];
                        strings[i] = strings[j];
                        strings[j] = rep;
                        
                    }
                }
            }

            System.out.println("\nThe lexicographical order of the strings you entered are as follows: ");

            for(int i = 0; i < 3; i++) 
            {
                System.out.println(strings[i]);
            }
        }
    }
}
