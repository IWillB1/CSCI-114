/**
 * <h2>Fraction.java - Creates fraction objects to be utilized by the Main.java class</h2>
 *
 * <h3>Instance variables:</h3>
 * <ul>
 *     <li> <code>numerator</code> (<b>char</b>) - numerator of the fraction
 *     <li> <code>denominator</code> (<b>int</b>) - denominator of the fraction
 * </ul>
 *
 * @author Will Bouasisavath
 * @version Module 6 Homework Project 4
 *
 */

public class Fraction 
{

    int numerator, denominator;

    // Constructor for a Fraction object
    public Fraction(int numerator, int denominator) 
    {
        this.numerator = numerator;
        this.denominator = denominator;
    }

    // Getter for the numerator
    public int getNumerator() 
    {
        return numerator;
    }

    // Setter for the numerator
    public void setNumerator(int numerator) 
    {
        this.numerator = numerator;
    }

    // Getter for the denominator
    public int getDenominator() 
    {
        return denominator;
    }

    // Setter for the denominator variable
    public void setDenominator(int denominator) 
    {
        this.denominator = denominator;
    }

    // A method that shows the fraction
    public String showFraction() 
    {
        return numerator + "/" + denominator;
    }

    //eturn true or false, depending on if the fractions are equal
    public boolean equals (Fraction another) 
    {

        double v1 = another.numerator + 0.00;
        double v2 = another.denominator + 0.00;
        double v3 = denominator + 0.00;
        double v4 = numerator + 0.00;

        double numeratorRatio = (v1 / v4);
        double denominatorRatio = (v2 / v3);

        if (denominator == 0 || another.denominator == 0) 
        {
            return false;
        }
            if (numeratorRatio == denominatorRatio) 
            {
            return true;
            }
            else 
            {
            return false;
            }
    }

    // Return a string of the fraction and it's equivalent decimal form
    public String toString() 
    {
        double fraction = numerator / denominator;
        return "The fraction " + showFraction() + " evaluates to " + String.format("%.2f", fraction);
    }
}