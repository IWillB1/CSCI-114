/**
 * <h2>Main.java - Utilizing objects from Fraction.java class</h2>
 *
 * <h3>Problem Statement:</h3>
 * <p> Write a program that performs actions with fractions using objects and methods</p>
 *
 * <h3>Algorithm:</h3>
 * <p>In main:</p>
 * <ol>
 *     <li>Create 6 <code>fraction</code> objects with the data of fractions 1/4, 5/20, 5/9, 85/153, -6/4, -125/83
 *     <li>Display 3 statements comparing if (1/4 5/20 | 5/9 85/153 | -6/4 -125/83) are equal using the <code>fraction.equals(anotherFraction())</code> </li>
 * </ol>
 *
 * @author Will Bouasisavath
 * @version Module 6 Homework Project 4
 *
 */

public class Main 
{

    public static void main(String[] args) 
    {

        Fraction one = new Fraction(1, 4);
        Fraction two = new Fraction(5, 20);
        Fraction three = new Fraction(5, 9);
        Fraction four = new Fraction(85, 153);
        Fraction five = new Fraction(-6, 4);
        Fraction six = new Fraction(-125, 83);

        System.out.println("Saying that 1/4 and 5/20 are equal is " + one.equals(two));
        System.out.println("Saying that 5/9 and 85/153 are equal is " + three.equals(four));
        System.out.println("Saying that -6/4 and -125/83 are equal is " + five.equals(six));

    }
}
