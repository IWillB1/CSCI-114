import java.util.Scanner;
/**
 * <h2>Response.java - Respond to a question, exclamation, or sentence</h2>
 *
 * <h3>Problem Statement:</h3>
 * <p> Write a program that takes a one-line sentence as input from the keyboard and prints a response based on what the sentence ends with.</p>
 *
 * <h3>Algorithm:</h3>
 * <p>In main:</p>
 * <ol>
 *     <li>Create Scanner
 *     <li>Prompt user for a sentence
 *     <li>Store the answer in a <b>String</b> called <code>sentence</code>
 *     <li>Store the last character in a <b>char</b> called <code>end</code>
 *     <li>Formulate the response with the following logic
 *          <ul>
 *              <li>If <code>end</code> is '?'
 *                  <ul>
 *                      <li>If <code>sentence</code> length is an even number
 *                         <ul>
 *                          <li>Print a statement saying Yes
 *                         </ul>
 *                      <li>Else
 *                             <ul>
 *                               <li>Print a statement saying No
 *                             </ul>
 *                  </ul>
 *              <li>If <code>end</code> is '!'
 *                  <ul>
 *                      <li>Print a statement saying Wow
 *                  </ul>
 *              <li>Else, print a statement saying 'You always say' followed by the input string in quotes
 *          </ul>
 * </ol>
 *
 * @author Will Bouasisavath
 * @version Module 6 Homework Project 1
 *
 */
public class Response 
{
    public static void main(String[] args) 
    {
        
        Scanner in = new Scanner(System.in);

        System.out.print("Please enter a sentence: ");
        String sentence = in.nextLine();

        String end = sentence.substring(sentence.length()-1);

        if (end.equals("?")) 
        {

            if ((sentence.length() % 2) == 0)
            {
                
                System.out.print("Yes");
                
            }

            else 
            {
                
                System.out.print("No");
                
            }
        }

        else if (end.equals("!")) 
        {

            System.out.print("Wow");

        }

        else 
        {

            System.out.printf("You always way say \"%s\"", sentence);

        }
    }
}
