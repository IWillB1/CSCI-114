import java.util.Scanner;

/**
 * <h2>CarRentalQuote.java - determines the total price to rent a car based on the car's size, color, and days rented</h2>
 *
 * <h3>Problem Statement:</h3>
 * <p> Write a program that determines the total price to rent a car based on certain parameters which the user will enter from their keyboard:
 * <ul>
 *     <li>The desired car size (full or economy)
 *     <li>The desired color of the car (black or white or red)
 *     <li>The desired number of days to rent
 * </ul>
 *
 * <h3>Algorithm:</h3>
 * <p>In main:</p>
 * <ol>
 *     <li>Create Scanner
 *     <li>Prompt user for <code>carSize</code> ('F' for full or 'E' for economy)
 *     <li>Store the answer in a <b>char</b> called <code>carSize</code>
 *     <li>Prompt the user for <code>carColor</code> ('B' for black or 'W' for white or 'R' for red)
 *     <li>Store the car color in a <b>char</b> called <code>carColor</code>
 *     <li>Prompt the user for the desired number of days to rent the car
 *     <li>Store the input in an <b>int</b> called <code>rentalDays</code>
 *     <li>Calculate the quote using exact weeks and days
 *          <ul>
 *              <li>Create <b>int</b> <code> weeks </code>
 *              <li><code>weeks</code> equals <code>rentalDays</code> / 7
 *              <li><code>days</code> equals <code>rentalDays</code> % 7
 *              <li>Create <b>double</b>s <code>dailyRate</code> and <code>weeklyRate</code> equal to 0
 *              <li>Switch case <code>carSize</code> 'F'
 *                  <ul>
 *                      <li><code>dailyRate</code> equals 39.40
 *                      <li><code>weeklyRate</code> equals 216.25
 *                  </ul>
 *              <li>Switch case <code>carSize</code> 'E'
 *                  <ul>
 *                      <li><code>dailyRate</code> equals 25.50
 *                      <li><code>weeklyRate</code> equals 120.50
 *                  </ul>
 *              <li><code>rentalCost1</code> equals <code>weeks * weeklyRate + days * dailyRate</code>
 *          </ul>
 *     <li>Calculate the quote using number of complete weeks + 1
 *          <ul>
 *              <li>Create <b>int</b> <code>weeks</code>
 *              <li><code>weeks</code> equals <code>(rentalDays / 7) + 1</code>
 *              <li>If <code>carSize</code> equals 'F', <code>weeklyRate</code> equals 216.25
 *              <li>Else, <code>weeklyRate</code> equals 120.50
 *              <li><code>rentalCost2</code> equals <code>weeks * weeklyRate</code>
 *          </ul>
 *     <li> If <code>carColor</code> is 'R'
 *     <ul>
 *         <li><code>rentalCost</code> equals <code>rentalCost</code> * 1.15
 *     </ul>
 *     <li> Display <code>carColor</code> and <code>carSize</code> and <code>rentalDays</code> and the lowest rental cost to the user
 * </ol>
 *
 * @author Will Bouasisavath
 * @version Module 6 Lab
 *
 */

public class CarRentalQuote 
{
    
    private static final double ECONOMY_DAILY = 25.50;
    private static final double ECONOMY_WEEKLY = 120.50;
    private static final double FULL_DAILY = 39.40;
    private static final double FULL_WEEKLY = 216.25;
    private static final double SURCHARGE = 1.15;

    public static void main(String[] args) 
    {
        Scanner in = new Scanner(System.in);

        System.out.print("Please enter 'E' if your car is economy and 'F' if your car full size: ");
        char carSize = in.nextLine().toUpperCase().charAt(0);

        System.out.print("Please enter 'W' if your car is white and 'B' if your car is black and 'R' if your car is red: ");
        char carColor = in.nextLine().toUpperCase().charAt(0);

        System.out.print("Please enter the number of days you are renting the car: ");
        int rentalDays = in.nextInt();

        int weeks = rentalDays / 7;
        int days = rentalDays % 7;

        double dailyRate = 0, weeklyRate = 0, rentalCost1 = 0, rentalCost2 = 0;

        switch(carSize) 
        {
            case 'F':
                dailyRate = FULL_DAILY;
                weeklyRate = FULL_WEEKLY;
                break;
            case 'E':
                dailyRate = ECONOMY_DAILY;
                weeklyRate = ECONOMY_WEEKLY;
                break;
            default:
                System.out.print("Car is wrong size");
        }

        rentalCost1 = weeks * weeklyRate + days * dailyRate;

        weeks++;

        rentalCost2 = weeks * weeklyRate;

        if (carColor == 'R')
        {
            rentalCost1 *= SURCHARGE;
            rentalCost2 *= SURCHARGE;
        }

        System.out.println("Quote for a " + (carColor == 'W' ? "white" : carColor == 'B' ? "black" : "red (a 15% surcharge)") +
                " " + (carSize == 'F' ? "full size" : "economy") + " for " + rentalDays + " days:" );
        System.out.printf("Between the two possible rates which were $%.2f and $%.2f, the best rate for you is $%.2f", rentalCost1, rentalCost2, (rentalCost1 >= rentalCost2 ? rentalCost2 : rentalCost1));
        
    }
}